float lus_luma(vec3 c) {
    return dot(c, vec3(0.23, 0.67, 0.10));
}

float lus_dusk(float day) {
    return smoothstep(0.0, 0.16, day) * (1.0 - smoothstep(0.18, 0.72, day));
}

float lus_evening() {
    float tick = float(WorldTime);
    return smoothstep(6000.0, 12000.0, tick) * (1.0 - smoothstep(18000.0, 22000.0, tick));
}

vec3 lus_palette(vec3 source, float day, float outside) {
    vec3 c = max(source, vec3(0.0)) * (Brightness * exp2(Exposure));
    float lum = lus_luma(c);
    float highlight = smoothstep(0.14, 0.82, lum);
    vec3 shadeTint = mix(vec3(1.0), mix(vec3(0.83, 0.94, 1.13), vec3(0.89, 0.97, 1.055), day), PackLusShadowCoolness);
    float dusk = lus_dusk(day);
    vec3 lightTint = mix(vec3(1.0), vec3(1.10, 1.035, 0.90), PackLusSunWarmth * day);
    vec3 twilightLight = mix(vec3(1.14, 1.025, 0.88), vec3(1.20, 1.01, 0.80), lus_evening());
    lightTint = mix(lightTint, twilightLight, dusk * PackLusHorizonWarmth * PackLusSunWarmth);
    // A camera underground must not make every nearby torch blue.
    float palette = LUS_PALETTE_AMOUNT * outside * (1.0 - 0.45 * clamp(Wetness, 0.0, 1.0));
    c *= mix(vec3(1.0), mix(shadeTint, lightTint, highlight), palette);
    // Lift only already-lit outdoor midtones. Black pixels and indoor darkness stay dark.
    c += vec3(lum * (1.0 - clamp(lum, 0.0, 1.0))) * LUS_NIGHT_LIFT * (1.0 - day) * outside;
    float shade = 1.0 - smoothstep(0.08, 0.48, lum);
    c *= 1.0 + shade * PackLusShadowLift * 0.35;
    float darkNight = (1.0 - day) * outside * shade * PackLusNightAdaptation;
    vec3 nightColor = mix(c, vec3(lus_luma(c)) * vec3(0.84, 0.99, 1.16), 0.4);
    c = mix(c, nightColor, darkNight);
    c = mix(c, vec3(lus_luma(c)), clamp(Rain, 0.0, 1.0) * outside * PackLusRainDesaturation);
    float chroma = max(c.r, max(c.g, c.b)) - min(c.r, min(c.g, c.b));
    float saturation = Saturation + LUS_VIBRANCE * (1.0 - clamp(chroma * 2.0, 0.0, 1.0));
    c = mix(vec3(lus_luma(c)), c, saturation);
    // Smooth contrast keeps dark cave pixels distinguishable instead of clipping them.
    c = pow(max(c, vec3(0.0)), vec3(max(Contrast, 0.05))) * pow(0.45, 1.0 - max(Contrast, 0.05));
    c *= vec3(1.0 + Temperature * 0.12, 1.0, 1.0 - Temperature * 0.12);
    // Luminance-based shoulder keeps hue and does not lift all midtones.
    lum = lus_luma(c);
    float peak = max(lum - 0.46, 0.0);
    float mapped = min(lum, 0.46) + peak / (1.0 + peak * LUS_SHOULDER);
    vec3 shoulder = c * mapped / max(lum, 0.00001);
    c = mix(c, shoulder, clamp(ToneMapping, 0.0, 1.0));
    return pow(max(c, vec3(0.0)), vec3(1.0 / max(Gamma, 0.05)));
}
